﻿namespace Core.Application.Caching;

public class CacheSettings
{
    public int SlidingExpiration { get; set; }
}