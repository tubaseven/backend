﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using project.Domain.Entitites;

namespace project.Persistence.Contexts;

/// <summary>
/// Veritabanı ayarlarını yapar.
/// </summary>
public class BaseDbContext : DbContext
{
    protected IConfiguration Configuration { get; set; }
    public DbSet<User> Users { get; set; }
    public DbSet<OperationClaim> OperationClaims { get; set; }
    public DbSet<UserOperationClaim> UserOperationClaims { get; set; }
    public DbSet<RefreshToken> RefreshTokens { get; set; }

    public BaseDbContext(DbContextOptions dbContextOptions, IConfiguration configuration) : base(dbContextOptions)
    {
        Configuration = configuration;
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<User>(p =>
        {
            p.ToTable("Users").HasKey(u => u.Id);
            p.Property(u => u.Id).HasColumnName("Id");
            p.Property(u => u.FirstName).HasColumnName("FirstName");
            p.Property(u => u.LastName).HasColumnName("LastName");
            p.Property(u => u.Email).HasColumnName("Email");
            p.Property(u => u.PasswordSalt).HasColumnName("PasswordSalt");
            p.Property(u => u.PasswordHash).HasColumnName("PasswordHash");
            p.Property(u => u.Status).HasColumnName("Status");
            p.HasMany(c => c.UserOperationClaims);
            p.HasMany(c => c.RefreshTokens);
        });

        modelBuilder.Entity<OperationClaim>(p =>
        {
            p.ToTable("OperationClaims").HasKey(o => o.Id);
            p.Property(o => o.Id).HasColumnName("Id");
            p.Property(o => o.Name).HasColumnName("Name");
        });

        modelBuilder.Entity<UserOperationClaim>(p =>
        {
            p.ToTable("UserOperationClaims").HasKey(u => u.Id);
            p.Property(u => u.Id).HasColumnName("Id");
            p.Property(u => u.UserId).HasColumnName("UserId");
            p.Property(u => u.OperationClaimId).HasColumnName("OperationClaimId");
            p.HasOne(u => u.User);
            p.HasOne(u => u.OperationClaim);
        });

        modelBuilder.Entity<RefreshToken>(a =>
        {
            a.ToTable("RefreshTokens").HasKey(k => k.Id);
            a.Property(p => p.Id).HasColumnName("Id");
            a.Property(p => p.UserId).HasColumnName("UserId");
            a.Property(p => p.Token).HasColumnName("Token");
            a.Property(p => p.Expires).HasColumnName("Expires");
            a.Property(p => p.Created).HasColumnName("Created");
            a.Property(p => p.CreatedByIp).HasColumnName("CreatedByIp");
            a.Property(p => p.Revoked).HasColumnName("Revoked");
            a.Property(p => p.RevokedByIp).HasColumnName("RevokedByIp");
            a.Property(p => p.ReplacedByToken).HasColumnName("ReplacedByToken");
            a.Property(p => p.ReasonRevoked).HasColumnName("ReasonRevoked");
            a.HasOne(p => p.User);
        });

//        OperationClaim[] operationClaimsEntitySeeds =
//{
//            new(1, "Admin"),
//            new(2, "User")
//        };
//        modelBuilder.Entity<OperationClaim>().HasData(operationClaimsEntitySeeds);
    }
}