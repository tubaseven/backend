﻿using Core.Persistence.Repositories;
using project.Application.Services.Repositories;
using project.Domain.Entitites;
using project.Persistence.Contexts;

namespace project.Persistence.Repositories;

/// <summary>
/// Operasyonlar için kullanılan repository sınıfı
/// </summary>
public class OperationClaimRepository : EfRepositoryBase<OperationClaim, BaseDbContext>, IOperationClaimRepository
{
    public OperationClaimRepository(BaseDbContext context) : base(context)
    {
    }
}