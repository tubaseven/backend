﻿using Core.Persistence.Repositories;
using project.Application.Services.Repositories;
using project.Domain.Entitites;
using project.Persistence.Contexts;

namespace project.Persistence.Repositories;

/// <summary>
/// Kullanıcı için işlem yetkilerini yöneten metotlarını tanımlar.
/// </summary>
public class UserOperationClaimRepository : EfRepositoryBase<UserOperationClaim,BaseDbContext>, IUserOperationClaimRepository
{
    public UserOperationClaimRepository(BaseDbContext context) : base(context)
    {
    }
}