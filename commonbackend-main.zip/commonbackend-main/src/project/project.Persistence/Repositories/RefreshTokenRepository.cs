﻿using Core.Persistence.Repositories;
using project.Application.Services.Repositories;
using project.Domain.Entitites;
using project.Persistence.Contexts;

namespace project.Persistence.Repositories;

/// <summary>
/// Token yenileme işlemleri için repository sınıfı
/// </summary>
public class RefreshTokenRepository : EfRepositoryBase<RefreshToken, BaseDbContext>, IRefreshTokenRepository
{
    public RefreshTokenRepository(BaseDbContext context) : base(context)
    {
    }
}