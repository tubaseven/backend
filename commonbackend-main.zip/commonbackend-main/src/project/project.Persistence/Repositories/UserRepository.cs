﻿using Core.Persistence.Repositories;
using project.Application.Services.Repositories;
using project.Domain.Entitites;
using project.Persistence.Contexts;

namespace project.Persistence.Repositories;

/// <summary>
/// Kullanıcılar için metotların bulunduğu repository sınıfıdır.
/// </summary>
public class UserRepository : EfRepositoryBase<User,BaseDbContext>, IUserRepository
{
    public UserRepository(BaseDbContext context) : base(context)
    {
    }
}