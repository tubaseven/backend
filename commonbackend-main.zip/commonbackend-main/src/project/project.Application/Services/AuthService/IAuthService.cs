﻿using Application.Helper.JWT;
using project.Domain.Entitites;

namespace project.Application.Services.AuthService;

/// <summary>
/// Kullanıcı giriş işlemleri için kullanılar servis imzası
/// </summary>
public interface IAuthService
{
    Task<AccessToken> CreateAccessToken(User user);
    Task<RefreshToken> CreateRefreshToken(User user, string ipAddress);
    Task<RefreshToken> AddRefreshToken(RefreshToken refreshToken);
}