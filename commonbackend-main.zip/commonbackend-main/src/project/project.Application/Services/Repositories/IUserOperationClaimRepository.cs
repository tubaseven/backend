﻿using Core.Persistence.Repositories;
using project.Domain.Entitites;

namespace project.Application.Services.Repositories;

/// <summary>
/// Kullanıcı için işlem yetkilerini yöneten metotların imzasını tanımlar.
/// </summary>
public interface IUserOperationClaimRepository : IAsyncRepository<UserOperationClaim>, IRepository<UserOperationClaim>
{
    
}