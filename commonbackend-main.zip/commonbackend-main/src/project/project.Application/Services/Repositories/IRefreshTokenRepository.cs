﻿using Core.Persistence.Repositories;
using project.Domain.Entitites;

namespace project.Application.Services.Repositories;

/// <summary>
/// Token Yenileme Metotların imzasını tutar.
/// </summary>
public interface IRefreshTokenRepository : IAsyncRepository<RefreshToken>, IRepository<RefreshToken>
{
    
}