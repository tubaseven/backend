﻿using Core.Persistence.Repositories;
using project.Domain.Entitites;

namespace project.Application.Services.Repositories;

/// <summary>
/// Kullanıclar için metotların imzalarını tutar.
/// </summary>
public interface IUserRepository : IAsyncRepository<User>, IRepository<User>
{
    
}