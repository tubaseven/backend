﻿using Core.Persistence.Repositories;
using project.Domain.Entitites;

namespace project.Application.Services.Repositories;

/// <summary>
/// Operasyonlar için metotların imzasını tanımlar.
/// </summary>
public interface IOperationClaimRepository : IAsyncRepository<OperationClaim>, IRepository<OperationClaim>
{
    
}