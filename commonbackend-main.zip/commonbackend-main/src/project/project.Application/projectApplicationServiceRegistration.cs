﻿using System.Reflection;
using Application.Helper.JWT;
using Core.Application.Authorization;
using FluentValidation;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using project.Application.Features.Auths.Rules;
using project.Application.Features.OperationClaims.Rules;
using project.Application.Features.UserOperationClaims.Rules;
using project.Application.Services.AuthService;

namespace project.Application;

/// <summary>
/// Application Katmanı için servisleri kayıt eder.
/// </summary>
public static class projectApplicationServiceRegistration
{
    public static IServiceCollection AddprojectApplicationServices(this IServiceCollection services)
    {
        services.AddAutoMapper(Assembly.GetExecutingAssembly());
        services.AddMediatR(Assembly.GetExecutingAssembly());

        services.AddScoped<AuthBusinessRules>();
        services.AddScoped<UserOperationClaimBusinessRules>();
        services.AddScoped<OperationClaimBusinessRules>();

        services.AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());
        //services.AddTransient(typeof(IPipelineBehavior<,>), typeof(CachingBehavior<,>));
        //services.AddTransient(typeof(IPipelineBehavior<,>), typeof(CacheRemovingBehavior<,>));
        //services.AddTransient(typeof(IPipelineBehavior<,>), typeof(LoggingBehavior<,>));
        //services.AddTransient(typeof(IPipelineBehavior<,>), typeof(RequestValidationBehavior<,>));
        services.AddTransient(typeof(IPipelineBehavior<,>), typeof(AuthorizationBehavior<,>));

        services.AddScoped<IAuthService, AuthManager>();
        services.AddScoped<ITokenHelper, JwtHelper>();
        return services;
    }
}