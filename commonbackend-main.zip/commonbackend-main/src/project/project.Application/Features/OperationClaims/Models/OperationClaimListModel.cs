﻿using Core.Persistence.Paging;
using project.Application.Features.OperationClaims.Dtos;

namespace project.Application.Features.OperationClaims.Models;

/// <summary>
/// Operasyon Claim için geriye dönen sayfalanmış veri modeli
/// </summary>
public class OperationClaimListModel : BasePageableModel
{
    public IList<OperationClaimListDto> Items { get; set; }
}