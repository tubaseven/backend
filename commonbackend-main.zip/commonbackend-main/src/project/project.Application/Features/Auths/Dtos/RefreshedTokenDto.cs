﻿using Application.Helper.JWT;
using project.Domain.Entitites;

namespace project.Application.Features.Auths.Dtos;

/// <summary>
/// Token bilgileri
/// </summary>
public class RefreshedTokenDto
{
    public AccessToken AccessToken { get; set; }
    public RefreshToken RefreshToken { get; set; }
}