﻿namespace project.Application.Features.Auths.Dtos;

public class LoginedDto : RefreshedTokenDto
{
    
}