﻿namespace project.Application.Features.Auths.Dtos;

public class RegisteredDto : RefreshedTokenDto
{
    
}